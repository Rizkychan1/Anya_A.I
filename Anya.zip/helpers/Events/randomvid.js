export default async function on({ Exp, cht, ev, is }) {
    // Daftar file untuk dikirim secara acak
    const randomFiles = [
"https://files.catbox.moe/pk69n7.mp4",
"https://files.catbox.moe/oydyrk.mp4",
"https://files.catbox.moe/6jn71z.mp4",
"https://files.catbox.moe/5nk6ph.mp4",
"https://files.catbox.moe/w81od0.mp4",
"https://files.catbox.moe/k2bick.mp4",
"https://files.catbox.moe/fqwn5m.mp4",
"https://files.catbox.moe/net6kr.mp4",
"https://files.catbox.moe/c8es17.mp4",
"https://files.catbox.moe/twtjnl.mp4",
 "https://files.catbox.moe/x4ynq4.mp4", 
"https://files.catbox.moe/8b4hlh.mp4", 
"https://files.catbox.moe/hzhuvn.mp4", 
"https://files.catbox.moe/wkelkc.mp4", 
"https://files.catbox.moe/5006jo.mp4", 
"https://files.catbox.moe/sp055i.mp4", 
"https://files.catbox.moe/3qvgxq.mp4", 
"https://files.catbox.moe/hh0hkh.mp4", 
"https://files.catbox.moe/3peg9m.mp4", 
"https://files.catbox.moe/xr9y95.mp4", 
"https://files.catbox.moe/9tjls3.mp4", 
"https://files.catbox.moe/s6wnbm.mp4", 
"https://files.catbox.moe/cyhinv.mp4", 
"https://files.catbox.moe/x239h0.mp4", 
"https://files.catbox.moe/s731vd.mp4", 
"https://files.catbox.moe/buw86m.mp4", 
"https://files.catbox.moe/dn8ue6.mp4", 
"https://files.catbox.moe/0qcznd.mp4", 
"https://files.catbox.moe/cb05bz.mp4", 
"https://files.catbox.moe/wmdri5.mp4", 
"https://files.catbox.moe/jls6ts.mp4", 
"https://files.catbox.moe/ljl2ej.mp4", 
"https://files.catbox.moe/lymss6.mp4", 
"https://files.catbox.moe/cuyohi.mp4", 
"https://files.catbox.moe/ljl2ej.mp4", 
"https://files.catbox.moe/i9pmmx.mp4",
"https://files.catbox.moe/h5frr3.mp4",
"https://files.catbox.moe/mzvggm.mp4",
"https://files.catbox.moe/7g54n6.mp4",
"https://files.catbox.moe/nw4oct.mp4",
"https://files.catbox.moe/86qkik.mp4",
"https://files.catbox.moe/gqkt3w.mp4",
"https://files.catbox.moe/ictvau.mp4",
"https://files.catbox.moe/iptt4m.mp4",
"https://files.catbox.moe/5j55r3.mp4",
        
    ];

    ev.on({
        cmd: ["tiktokrandom", "ttrandom"],
        listmenu: ["tiktokrandom"],
        tag: "downloader",
        isGroup: false
    }, async ({ cht }) => {
        try {
            // Pilih file secara acak
            const randomFile = randomFiles[Math.floor(Math.random() * randomFiles.length)];

            // Kirim file
            await Exp.sendMessage(cht.id, {
                video: { url: randomFile },
                caption: "🎥 Video Tiktok random berhasil dikirim!"
            });
        } catch (error) {
            console.error(error);
            cht.reply("❌ Terjadi kesalahan saat mengirim file random. Silakan coba lagi nanti.");
        }
    });
}
